import  webbrowser

user_term = input("Enter a search term: ")

webbrowser.open(f"https://google.com/search?={user_term}+website")